#include "PlaneFile.h"

void PlaneFile::SavePlane(PlaneTemplate pt)
{
}

PlaneTemplate PlaneFile::LoadPlane(PlaneId id)
{
	// ɾ��
	return PlaneTemplate();
}
