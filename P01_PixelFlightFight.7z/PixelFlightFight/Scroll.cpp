#include "Scroll.h"

Scroll::Scroll()
{
}

Scroll::~Scroll()
{
}

Scroll& Scroll::GetInstance()
{
	static Scroll scroll;
	return scroll;
}

void Scroll::AllMove()
{
}

void Scroll::RenderToWindows()
{
}

void Scroll::RenderInfo()
{
}

void Scroll::InitiateInstance(PlaneTemplate pt, Coordinate pos)
{
}

void Scroll::DeleteInstance(InsId id)
{
}
